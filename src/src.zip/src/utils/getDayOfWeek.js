module.exports=()=>{
    const today = new Date(Date.now());
    return dayOfWeek = today.getDay();
}

