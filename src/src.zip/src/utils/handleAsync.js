module.exports= fn , socket =>{
    fn(socket).then().catch()
}